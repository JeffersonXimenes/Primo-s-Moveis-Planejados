# Primos Moveis Planejados

 Neste repositório, encontra-se todo o processo que foi utilizado na Criação do Sistema da Primos Moveis. Na aba Projects, encontramos como foi dividido cada processo e como foi tratado. 
 
 Em Branch: Encontramos todas as versões do Sistema. no Ramo Master, encontra a versão final e utilizada. 
 
 Versâo V3:

Criação dos models ClienteModel, TelefoneModel, EndereçosModel,Cargo,Model,FuncionarioModels,TiposModels e VendasModels.

Criação do modulo resource Clientes, Telefones, Endereços,Cargos, Funcionarios, Tipo de pagamento e vendas.

Metodos POST E GET 100%: 

Metodo DELETE 80%(Cliente e funcionario, Cargo,Tipo de pagamento):

Metodo PUT 95% (Cliente e funcionario)

API em funcionamento pelo POSTMAN.

 
 OBS: Para Execução do Projeto é necessário ter as seguintes PIPS INSTALADAS:
- pip install Flask
- pip install Flask-SQLAlchemy
- pip install Flask-EXT
- pip install Jinja2
- pip install pyodbc
- pip install requests
- pip install mypy_entensions 
- pip install typing extensions 
- pip install wrap_connection

Após a instalação, execute app.py
 
 Link do Site: --- AINDA SEM LINK --- 
 Link aplicativo Mobile --- AINDA SEM LINK --- 
 
- Equipe: Anna Kelly, Gabriel Bezerra, Hellen Mendes, João Victor e Jefferson Ximenes. 
