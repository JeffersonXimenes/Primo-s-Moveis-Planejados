#inicia modulo
