

function envia_data() {
    
    var now = new Date();
    now.format("dd/MM/yyyy");
    console.log(now)
}


var d = new Date();
console.log(d.toDate('dd/mm/yyyy hh:ii:ss'));

console.log(d.toDate('mm/dd/yyyy hh:ii:ss'));

console.log(d.toDate('yyyy-mm-dd'));

console.log(d.toDate('yyyy-dd'));